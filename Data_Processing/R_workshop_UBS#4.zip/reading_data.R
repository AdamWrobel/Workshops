
# read from csv file - try to read macroeconomic_data_USA.csv using read.table or read.csv function


# save the file as as macro_USA


# read from excel file
install.packages('readxl')
library(readxl)
# try to read sheet '2014' from lifetables1990-2014.xlsx' file using read_excel function



# save the file as life_table_2014
